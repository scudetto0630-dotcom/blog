<?php
if(!defined('ABSPATH'))exit;
/** Public additions only use packaged facts and approved packaged photographs. */
function hsh_growth_summaries(){return array(
'kirin-riku-review'=>'初めて買った陸は、当時は苦手でコーラ割りに。原料・造りと、ウイスキーに慣れる前の感想。',
'busker-irish-whiskey-review'=>'2本目のバスカー緑で、おいしいと思えた。炭酸とコーラで飲んだ頃の話と、3種類の樽の特徴。',
'glen-grant-arboralis-review'=>'4本目のジムビームが苦手だったので、5本目は慎重に。紹介で聞いたフルーツの例えを、どう受け止めて選んだか。',
'nikka-from-the-barrel-review'=>'力強さと甘み、ハイボールにしたときの香り。こぼれやすくても好きな、フロム・ザ・バレルの感想。',
'jim-beam-first-impression'=>'グラスセットで買った4本目は、自分には合わなかった。ジムビームを飲んだ感想と、5本目を慎重に選んだ理由。',
'before-welcoming-cat'=>'猫を迎える前に用意する物と、部屋を片付けるときの注意点をまとめています。',
'manmos-cat-life'=>'迎えた翌日には枕の上へ。甘えるときの声や好きなおもちゃ、紙砂を選んだ理由など、まんもすとの暮らしを写真と一緒に。',
'cat-teaser-small-parts'=>'100均の羽付きねこじゃらしを愛用中。小さな部品の外れやすさと、遊んだ後の片付けについて書いています。',
'cat-vet-routine'=>'通院の持ち物と、診察で伝えたい猫の様子を紹介しています。',
'cat-carrier-checklist'=>'5.5kgのまんもすを入れるとリュックキャリーがへこみ、古いキャリーを使い直した経緯を書いています。',
'glenlivet-12-first-bottles'=>'3本目に買ったウイスキーは、スーパーで見つけたグラス付きのグレンリベット12年。飲みやすさと、花のような香りが好きになった。',
'single-malt-label-guide'=>'ラベルのどこを見る？ 商品名・年数・容量・度数の読み方と、容量が違う2本を100ml当たりの値段で比べる方法。',
'sherry-cask-notes'=>'ぶどうパンが大好きで、香りの例えにひかれて購入。グレンファークラス12年をストレートとハーフロックで飲んだ感想と、何度も買う理由。',
'highball-measure-and-adjust'=>'ハイボールの味が薄い？ それとも炭酸が弱い？ 分量・氷・注ぎ方を順に見直し、計算機で好みの割合も試せます。',
'it-data-work-flow'=>'正社員での転職、生活の変化で選んだ派遣、知人から紹介された個人事業主。今の働き方が合う理由と、それでも不安になる瞬間を、自分の経緯から書いています。',
'starting-it-without-specialty'=>'ITに興味はあっても、何をしたいか分からなかった約1年。知人の紹介で出会った仕事を振り返り、職種だけでなく働く条件や過去の経験から考える方法を書きました。',
'ai-data-extraction-checks'=>'AIの抽出結果に抜けや誤りがないか、架空の4行を使って確かめます。依頼文と正解例を比べ、IDや空欄を確認する練習ができます。',
'employee-vs-self-employed'=>'給与と報酬、休暇、時間の自由、保険や年金、事務の負担を比較。正社員にも個人事業主にもよさがある立場で、自分に合う働き方を考えます。',
'freelance-and-sole-proprietor'=>'似た意味で使われるフリーランスと個人事業主。個人・法人、雇用・業務委託の違いを、公的な案内と自分の経緯を交えて説明します。',
'freelance-sales-and-take-home'=>'売上40万円の架空例で、費用を引いた後にも考えたい税金・社会保険・入金時期を紹介。給与との比較と、経費が無料ではない理由も説明します。',
'changing-job-or-working-style'=>'仕事内容、職場、雇用形態のどこを変えたいか。正社員・派遣・個人事業主を経験した立場で、残したい条件と相談先を考えます。',
'freelance-contract-before-start'=>'業務委託を始める前に、報酬、支払期日、担当範囲、変更や終了、情報の扱いを確認。フリーランス法の公式案内と相談先も紹介します。',
'freelance-days-off'=>'休む日を選べても、収入や連絡の扱いは契約次第。有給休暇との違いから、報酬の決まり方、急に働けない日の備えまで、自分に合う休み方を考えます。',
'freelance-health-insurance'=>'退職後の健康保険は、国保・任意継続・家族の扶養が主な候補。保険料の比べ方と、協会けんぽの申出期限、家族や年金も含めて確かめたいことを紹介します。',
'freelance-contract-renewal-end'=>'更新するか、いつ作業を終えるか、最後の報酬はいつ入るか。業務委託の終了前後に見る条件と、30日前予告の対象、引き継ぎや相談先を紹介します。',
'csv-import-seven-checks'=>'CSVを開いたら文字化けしたり、先頭の0が消えたり。元ファイルを残して見る7項目と、0が消えたときの切り分け方。');}
function hsh_growth_next($slug){$pairs=array(
'kirin-riku-review'=>'busker-irish-whiskey-review','busker-irish-whiskey-review'=>'glenlivet-12-first-bottles',
'glen-grant-arboralis-review'=>'jim-beam-first-impression','jim-beam-first-impression'=>'glen-grant-arboralis-review','nikka-from-the-barrel-review'=>'highball-measure-and-adjust',
'before-welcoming-cat'=>'manmos-cat-life','manmos-cat-life'=>'cat-carrier-checklist','cat-carrier-checklist'=>'cat-vet-routine','cat-vet-routine'=>'cat-carrier-checklist','cat-teaser-small-parts'=>'manmos-cat-life',
'glenlivet-12-first-bottles'=>'sherry-cask-notes','sherry-cask-notes'=>'single-malt-label-guide','single-malt-label-guide'=>'glenlivet-12-first-bottles','highball-measure-and-adjust'=>'glenlivet-12-first-bottles',
'starting-it-without-specialty'=>'changing-job-or-working-style','it-data-work-flow'=>'employee-vs-self-employed','ai-data-extraction-checks'=>'csv-import-seven-checks','csv-import-seven-checks'=>'ai-data-extraction-checks','employee-vs-self-employed'=>'freelance-sales-and-take-home','freelance-and-sole-proprietor'=>'employee-vs-self-employed','freelance-sales-and-take-home'=>'freelance-contract-before-start','changing-job-or-working-style'=>'employee-vs-self-employed','freelance-contract-before-start'=>'freelance-contract-renewal-end','freelance-days-off'=>'employee-vs-self-employed','freelance-health-insurance'=>'freelance-sales-and-take-home','freelance-contract-renewal-end'=>'freelance-contract-before-start');return $pairs[$slug]??'';}
function hsh_growth_nav(){return '<nav class="hsh-explore-nav" aria-label="写真と記事を探す"><a href="'.esc_url(home_url('/hsh-gallery/')).'">まんもすの写真</a><a href="'.esc_url(home_url('/hsh-whisky-notes/')).'">飲んだウイスキーのメモ</a><a href="'.esc_url(home_url('/hsh-updates/')).'">最近の更新</a></nav>';}
add_action('init',function(){add_option('hsh_all_articles_counted_since',wp_date('Y_m_d'),'',false);});
function hsh_growth_popular(){
    $totals=array();$start=max(wp_date('Y_m_d',time()-29*DAY_IN_SECONDS),(string)get_option('hsh_all_articles_counted_since',wp_date('Y_m_d')));$end=wp_date('Y_m_d');
    foreach((array)get_option('hsh_request_counts',array()) as $day=>$rows)if($day>=$start&&$day<=$end)foreach($rows as $slug=>$count)if(isset(hsh_growth_summaries()[$slug]))$totals[$slug]=($totals[$slug]??0)+max(0,(int)$count);
    $totals=array_filter($totals,function($n){return $n>=10;});if(count($totals)<3||array_sum($totals)<50)return '';arsort($totals);$out='<section class="hsh-popular"><h2>最近、読まれている記事</h2><p>直近30日のおおよその閲覧状況を参考にしています。</p><ul>';
    foreach(array_slice($totals,0,3,true) as $slug=>$n){$p=get_page_by_path($slug,OBJECT,'post');if($p&&$p->post_status==='publish')$out.='<li><a href="'.esc_url(get_permalink($p)).'">'.esc_html($p->post_title).'</a></li>';}
    return $out.'</ul></section>';
}
function hsh_growth_gallery(){
    $out='<section class="hsh-gallery-page"><p>爪とぎの上や枕の上でくつろぐ、まんもすの写真を集めました。</p>'.hsh_reader_gallery_filters().'<div class="hsh-photo-grid">';
    foreach(hsh_photo_manifest()['assets'] as $a)if($a['kind']==='provided'&&$a['subject']==='manmos')$out.='<figure class="hsh-photo"'.(hsh_reader_gallery_matches($a)?'':' hidden').' data-photo-tags="'.esc_attr(implode(' ',$a['tags']??array('relax'))).'">'.hsh_photo_image($a,false,'(max-width:600px) calc(100vw - 44px), 360px').hsh_photo_figcaption(array_merge($a,array('caption'=>$a['alt']))).'</figure>';
    return $out.'</div><p><a href="'.esc_url(home_url('/manmos-cat-life/')).'">まんもすとの暮らしを読む →</a></p></section>';
}
function hsh_growth_tastes(){return array(
array('name'=>'キリンウイスキー 陸','image'=>'riku-generated','note'=>'初めて買ったウイスキー。当時はまだウイスキーに慣れていなくて、おいしいと思えず、コーラで割って飲んでいた。','reason'=>'','slug'=>'kirin-riku-review'),
array('name'=>'バスカー アイリッシュウイスキー','image'=>'busker-green-generated','note'=>'2本目に買ったバスカー緑は、おいしいと感じた。炭酸とコーラで交互に割って飲むうちに、ウイスキーの味にも慣れていった。','reason'=>'','slug'=>'busker-irish-whiskey-review'),
array('name'=>'グレンリベット12年','note'=>'3本目に買って、最初はハイボールで飲んだ。飲みやすくて、それまで買ったウイスキーより格段にうまいと感じた。花のような香りも好き。','reason'=>'YouTubeで気になっていたところ、スーパーでグラス付きのセットを見つけた。知っていた金額より少し安く、迷わず購入。','slug'=>'glenlivet-12-first-bottles'),
array('name'=>'ジムビーム','image'=>'jim-beam-generated','note'=>'グラスセットで買った4本目。自分にはかなり苦手で、次の1本を慎重に選ぶきっかけになった。','reason'=>'','slug'=>'jim-beam-first-impression'),
array('name'=>'グレングラント アルボラリス','image'=>'arboralis-generated','note'=>'5本目に選んだアルボラリスは、甘くて飲みやすかった。ジムビームが苦手だった後、慎重に選んだ理由を書いている。','reason'=>'','slug'=>'glen-grant-arboralis-review'),
array('name'=>'グレンファークラス12年','image'=>'article-sherry','note'=>'ぶどうパンに顔をうずめたみたいな香りが、とにかく好き。まろやかでうまいけど、ストレートではかすかにアルコールの刺激も感じる。','reason'=>'ぶどうパンが大好きで、YouTubeで聞いた香りの例えにひかれた。特別な日に飲みたくて、何度も買っている。','slug'=>'sherry-cask-notes'),
array('name'=>'フロム・ザ・バレル','image'=>'from-the-barrel-generated','note'=>'ストレートもハイボールも、力強さと甘みが好き。注ぎにくくても好きなボトルの話と一緒に。','reason'=>'','slug'=>'nikka-from-the-barrel-review'));}
function hsh_growth_whisky(){
    $out='<section class="hsh-taste-index"><p>最初に買ったのは<a href="#riku-taste">陸</a>、次が<a href="#busker-taste">バスカー アイリッシュウイスキー（バスカー緑）</a>、3本目が<a href="#glenlivet-taste">グレンリベット12年</a>。4本目は<a href="#jim-beam-taste">ジムビーム</a>、5本目は<a href="#arboralis-taste">アルボラリス</a>だった。飲んでみて好きだったものも、口に合わなかったものも、自分の感想を残している。</p><p>普段はその日の気分で、飲みたいものを選ぶ。ハイボールはウイスキーを30ml入れて、炭酸はできるだけ多めに。グレンファークラスはストレートかハーフロックで、香りを楽しむのが好きだ。</p>';
    foreach(hsh_growth_tastes() as $r){$arboralis=strpos($r['name'],'アルボラリス')!==false;$out.='<article class="hsh-taste-card"'.' id="'.esc_attr(hsh_growth_taste_anchor($r['name'])).'"'.'><h2>'.esc_html($arboralis?'グレングラント アルボラリス':$r['name']).'</h2>';if(!empty($r['image'])){$asset=hsh_photo_manifest()['assets'][$r['image']];$out.='<figure class="hsh-photo hsh-taste-photo">'.hsh_photo_image($asset,false).'</figure>';}$out.='<p>'.esc_html($r['note']).'</p>';foreach($r['details']??array() as $paragraph)$out.='<p>'.esc_html($paragraph).'</p>';if($r['reason']!=='')$out.='<dl><dt>選んだ理由</dt><dd>'.esc_html($r['reason']).'</dd></dl>';if($r['name']==='フロム・ザ・バレル')$out.='<p><a href="https://www.nikka.com/brands/fromthebarrel/">フロム・ザ・バレルの公式商品案内</a></p>';if($r['name']==='バスカー アイリッシュウイスキー')$out.='<p><a href="https://whisk-e.co.jp/products/buskerirish/">バスカー アイリッシュウイスキーの公式商品案内</a></p>';if($r['slug'])$out.='<a href="'.esc_url(home_url('/'.$r['slug'].'/')).'">この銘柄の感想を読む →</a>';$out.='</article>';}
    $out.='<section class="hsh-next-bottle"><h2>次に気になっているのは、オーチャードハウス</h2><p>コンパスボックスのオーチャードハウスは、フルーツ感があると聞いて気になっている。ローソンで売っていた缶ハイボールは飲んでみたけど、あまり口に合わなかった。それでもボトルの方は飲んでみたい。まだ買っていないので、ボトルで飲むのを次の楽しみにしている。</p></section>';
    return $out.hsh_whisky_display_gallery().'<p><a href="'.esc_url(home_url('/highball-measure-and-adjust/')).'">ハイボールの分量を調整したいときはこちら</a></p></section>';
}
function hsh_whisky_display_gallery(){
    $manifest=hsh_photo_manifest();$out='<section class="hsh-whisky-photos"><h2>白州で撮った、ウイスキーの展示</h2><p>25年の夏に白州蒸溜所を見学したときの写真です。ここからは、展示されていたボトルを紹介します。</p><p><a href="'.esc_url(home_url('/hsh-hakushu-visit/')).'">初めての白州蒸溜所見学。写真と一緒に振り返る →</a></p><div class="hsh-photo-grid">';
    foreach($manifest['collections']['whisky-displays']??array() as $key){$a=$manifest['assets'][$key];$out.='<figure class="hsh-photo">'.hsh_photo_image($a,false,'(max-width:600px) calc(100vw - 44px), 360px').hsh_photo_figcaption($a).'</figure>';}
    return $out.'</div></section>';
}
function hsh_growth_updates(){
    $rows=array();foreach(hsh_catalog() as $a){$p=get_page_by_path($a['slug'],OBJECT,'post');if($p&&$p->post_status==='publish')$rows[]=array('post'=>$p,'date'=>get_post_modified_time('Y-m-d',false,$p));}
    $visit=get_page_by_path('hsh-hakushu-visit',OBJECT,'page');if($visit&&$visit->post_status==='publish'&&get_post_meta($visit->ID,'_hsh_bridge_owned',true)==='1')$rows[]=array('post'=>$visit,'date'=>get_post_modified_time('Y-m-d',false,$visit));
    usort($rows,function($a,$b){return strcmp($b['date'],$a['date']);});$out='<section class="hsh-updates"><p>最近更新した記事を、新しい順に並べています。</p><ul>';
    foreach($rows as $r)$out.='<li><time datetime="'.esc_attr($r['date']).'">'.esc_html(str_replace('-','/',$r['date'])).'</time> <a href="'.esc_url(get_permalink($r['post'])).'">'.esc_html($r['post']->post_title).'</a></li>';
    return $out.'</ul></section>';
}
add_shortcode('hsh_manmos_gallery','hsh_growth_gallery');add_shortcode('hsh_whisky_notes','hsh_growth_whisky');add_shortcode('hsh_updates','hsh_growth_updates');
add_action('wp_enqueue_scripts',function(){wp_enqueue_style('hsh-growth',plugin_dir_url(__FILE__).'assets/growth.css',array('hsh-reading'),'1.50.0');if(hsh_reader_managed()||is_front_page())wp_enqueue_script('hsh-growth',plugin_dir_url(__FILE__).'assets/growth.js',array(),'1.41.0',true);},110);
add_filter('the_content',function($content){
    if(!is_singular('post')||!in_the_loop()||!is_main_query())return $content;$p=get_post();if(!hsh_owned_blog_post($p))return $content;
    $slug=hsh_growth_next($p->post_name);$next=$slug?get_page_by_path($slug,OBJECT,'post'):null;$summaries=hsh_growth_summaries();
    if($next&&$next->post_status==='publish'&&preg_match_all('~<h2\b[^>]*>~i',$content,$m,PREG_OFFSET_CAPTURE)&&count($m[0])>=4){$nav='<aside class="hsh-context-link"><p>'.esc_html(hsh_reader_roles()[$slug]['related_label']??'こちらもどうぞ').'</p><a href="'.esc_url(get_permalink($next)).'">'.esc_html($next->post_title).'</a><p>'.esc_html($summaries[$slug]??'').'</p></aside>';$content.=$nav;}
    return $content;
},19);
add_filter('the_content',function($content){
    if(!is_singular('post')||!in_the_loop()||!is_main_query()||!hsh_owned_blog_post(get_post()))return $content;
    return $content.'<div class="hsh-share"><button type="button" data-hsh-copy="'.esc_url(get_permalink()).'">記事のURLをコピー</button><button type="button" data-hsh-share hidden>この記事を共有する</button><span role="status" aria-live="polite"></span></div>'.hsh_growth_nav();
},25);
add_action('wp_footer',function(){echo hsh_growth_nav();},25);
/** Replace theme defaults once, without adding conflicting OGP or schema nodes. */
function hsh_growth_metadata($html,$data,$modified=''){
    if(!$data||strpos($html,'</head>')===false)return $html;
    if(!empty($data['og:image']))$data['thumbnail']=$data['og:image'];
    if($modified!=='')$data['article:modified_time']=$modified;
    $head=substr($html,0,strpos($html,'</head>'));$tail=substr($html,strpos($html,'</head>'));$seen=array();
    $head=preg_replace_callback('~<meta\b[^>]*>~i',function($m)use($data,&$seen){if(!preg_match('~\b(?:name|property)\s*=\s*([\x22\x27])(.*?)\1~i',$m[0],$key))return $m[0];$k=strtolower($key[2]);if(!isset($data[$k]))return $m[0];if(isset($seen[$k]))return '';$seen[$k]=true;return '<meta '.((strpos($k,'og:')===0||strpos($k,'article:')===0)?'property':'name').'="'.esc_attr($k).'" content="'.esc_attr($data[$k]).'">';},$head);
    foreach($data as $k=>$value)if(!isset($seen[$k]))$head.='<meta '.((strpos($k,'og:')===0||strpos($k,'article:')===0)?'property':'name').'="'.esc_attr($k).'" content="'.esc_attr($value).'">'."\n";
    $head=preg_replace_callback('~<script\b[^>]*type=[\x22\x27]application/ld\+json[\x22\x27][^>]*>(.*?)</script>~is',function($m)use($data,$modified){$j=json_decode($m[1],true);if(!is_array($j))return $m[0];$walk=function(&$node)use(&$walk,$data,$modified){if(!is_array($node))return;$types=(array)($node['@type']??array());if(array_intersect($types,array('Article','BlogPosting','NewsArticle'))){$node['image']=array('@type'=>'ImageObject','url'=>$data['og:image'],'width'=>(int)$data['og:image:width'],'height'=>(int)$data['og:image:height']);$node['description']=$data['description'];if($modified!=='')$node['dateModified']=$modified;if(isset($node['headline'])&&is_string($node['headline']))$node['headline']=html_entity_decode($node['headline'],ENT_QUOTES|ENT_HTML5,'UTF-8');}foreach($node as &$v)if(is_array($v))$walk($v);};$walk($j);return '<script type="application/ld+json">'.wp_json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script>';},$head);
    return $head.$tail;
}
function hsh_growth_rendered($html){
    if(strpos($html,'</head>')===false)return $html;
    $modified='';if(is_singular('post')&&function_exists('hsh_studio_article_modified'))$modified=hsh_studio_article_modified(get_post());
    if(is_singular('post')){$p=get_post();if(!hsh_owned_blog_post($p)){if((int)$p->ID!==8||is_wp_error(hsh_intro_post()))return $html;$a=hsh_photo_manifest()['assets']['manmos-front'];}else $a=hsh_photo_for_slug($p->post_name);$description=hsh_reader_roles()[$p->post_name]['search_description']??$p->post_excerpt;$type='article';$url=get_permalink($p);$title=$p->post_title.' | ひろがる趣味暮らし';}
    elseif(is_page()&&(in_array((int)get_queried_object_id(),array_map('intval',(array)get_option('hsh_edit_pages',array())),true)||hsh_reader_scope())){$p=get_post();$m=hsh_photo_manifest();$key=$p->post_name==='hsh-hakushu-visit'?'hakushu-entrance':($p->post_name==='hsh-whisky-notes'?($m['topics']['whisky']??'manmos-tower'):'manmos-portrait');$key=$m['pages'][$p->post_name]??$key;$a=$m['assets'][$key]??null;$descriptions=array('お問い合わせ'=>'ひろがる趣味暮らしへのお問い合わせ。記事に関するご連絡はこちらからお送りください。','プライバシーポリシー'=>'ひろがる趣味暮らしの個人情報の取り扱いとプライバシーポリシーについて。','hsh-reading-list'=>'この端末で保存した、ひろがる趣味暮らしの記事をまとめて読み返せます。','hsh-hakushu-visit'=>'白州蒸溜所を初めて見学した25年の夏の感想。館内展示や飲み比べの写真と、これから行く前に公式案内で確認したい予約・アクセス情報をまとめます。','hsh-gallery'=>'うちの保護猫まんもすの写真。枕の上で休んだり、爪とぎに座ったり、いろいろな姿を集めました。','hsh-whisky-notes'=>'陸、バスカー アイリッシュウイスキー、グレンリベット12年、アルボラリス、グレンファークラス12年、ジムビーム、フロム・ザ・バレルなど、飲んだ感想の記事を銘柄ごとに選べます。','hsh-updates'=>'ひろがる趣味暮らしの最近の更新。猫・ウイスキー・ITの公開記事を更新日順に紹介します。');$description=$descriptions[rawurldecode($p->post_name)]??wp_trim_words(wp_strip_all_tags($p->post_content),70);$title=$p->post_title.' | ひろがる趣味暮らし';$type='website';$url=get_permalink($p);}
    elseif(is_front_page()||hsh_current_topic()){$m=hsh_photo_manifest();$key=hsh_current_topic()?($m['topics'][hsh_current_topic()]??'manmos-tower'):($m['home']??'manmos-tower');$a=$m['assets'][$key]??null;$description=hsh_current_topic()?hsh_topic_details()[hsh_current_topic()][4]:'保護猫まんもすとの暮らし、飲んだウイスキーの感想、フリーランスのデータ加工の仕事を書いています。';$type='website';$url=hsh_current_topic()?get_pagenum_link(max(1,(int)get_query_var('paged'))):home_url('/');$title=hsh_current_topic()?hsh_topics()[hsh_current_topic()][0].' | ひろがる趣味暮らし':'ひろがる趣味暮らし｜猫・ウイスキー・ITの仕事';}
    else return $html;
    if(!$a)return $html;$image=plugin_dir_url(__FILE__).'assets/photos/'.$a['file'];
    return hsh_growth_metadata($html,array('description'=>$description,'og:type'=>$type,'og:title'=>$title,'og:description'=>$description,'og:url'=>$url,'og:image'=>$image,'og:image:secure_url'=>$image,'og:image:type'=>'image/webp','og:image:width'=>(string)$a['width'],'og:image:height'=>(string)$a['height'],'og:image:alt'=>$a['alt'],'twitter:card'=>'summary_large_image','twitter:image'=>$image,'twitter:image:alt'=>$a['alt'],'twitter:title'=>$title,'twitter:description'=>$description),$modified);
}

/** Consolidate existing recommendation blocks; never rewrite the article itself. */
function hsh_growth_compact_followups($content) {
    $pattern='~<(nav|section|aside)\b[^>]*\bclass="(?:[^"]*\s)?(?:hsh-next-read|hsh-related|hsh-context-link|hsh-product-related)(?:\s[^"]*)?"[^>]*>.*?</\1>~si';
    $origin=parse_url(home_url('/'),PHP_URL_HOST);
    $blocks=array();$links=array();
    preg_match_all($pattern,$content,$matches,PREG_SET_ORDER);
    foreach($matches as $match){
        $block=$match[0];
        // Only merge the known text-only link blocks, preserving richer content intact.
        if(preg_match('~<(?:img|figure|table|form|blockquote|script)\b|\bid\s*=~i',$block))continue;
        preg_match_all('~<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>~si',$block,$anchors,PREG_SET_ORDER);
        if(!$anchors)continue;
        $accepted=array();
        foreach($anchors as $a){
            $url=html_entity_decode($a[1],ENT_QUOTES,'UTF-8');
            if(parse_url($url,PHP_URL_HOST)!==$origin||!in_array(parse_url($url,PHP_URL_SCHEME),array('http','https'),true)){$accepted=array();break;}
            $accepted[$url]=trim(wp_strip_all_tags($a[2]));
        }
        if(!$accepted)continue;
        $blocks[]=$block;
        foreach($accepted as $url=>$label)if(!isset($links[$url]))$links[$url]=$label;
    }
    $current=get_post(get_queried_object_id());
    $workstyle=$current?hsh_workstyle_followup_markup($current->post_name):'';
    if($workstyle!==''){
        if(!$blocks)return $content.$workstyle;
        $first=true;return preg_replace_callback($pattern,function($m)use($blocks,$workstyle,&$first){if(!in_array($m[0],$blocks,true))return $m[0];if($first){$first=false;return $workstyle;}return '';},$content);
    }
    if(count($blocks)<2)return $content;
    $current=get_post(get_queried_object_id());$next=$current?hsh_growth_next($current->post_name):'';
    if($next){$target=get_page_by_path($next,OBJECT,'post');if($target&&$target->post_status==='publish'){$url=get_permalink($target);$links=array($url=>get_the_title($target))+$links;}}
    $out='<nav class="hsh-related hsh-followups" aria-label="あわせて読みたい記事"><h2>あわせて読みたい記事</h2><ul>';
    $primary=true;
    foreach($links as $url=>$label){
        $slug=rawurldecode(basename(rtrim((string)parse_url($url,PHP_URL_PATH),'/')));
        $post=get_page_by_path($slug,OBJECT,'post');
        if($post&&$post->post_status==='publish')$label=get_the_title($post);
        $summary=$primary?(hsh_growth_summaries()[$slug]??''):'';
        $out.='<li'.($primary?' class="hsh-followup-primary"':'').'><a href="'.esc_url($url).'">'.esc_html($label).' <span aria-hidden="true">→</span></a>'.($summary!==''?'<p>'.esc_html($summary).'</p>':'').'</li>';$primary=false;
    }
    $out.='</ul></nav>';
    // Keep the first block's position, ahead of the profile and article tools.
    $first=true;
    return preg_replace_callback($pattern,function($m)use($blocks,$out,&$first){
        if(!in_array($m[0],$blocks,true))return $m[0];
        if($first){$first=false;return $out;}
        return '';
    },$content);
}
add_filter('the_content',function($content){
    if(!is_singular('post')||!in_the_loop()||!is_main_query()||!hsh_owned_blog_post(get_post()))return $content;
    return hsh_growth_compact_followups($content);
},29);

function hsh_growth_taste_anchor($name) {
    $ids=array('キリンウイスキー 陸'=>'riku-taste','バスカー アイリッシュウイスキー'=>'busker-taste','グレンリベット12年'=>'glenlivet-taste','グレングラント アルボラリス'=>'arboralis-taste','グレンファークラス12年'=>'glenfarclas-taste','フロム・ザ・バレル'=>'from-the-barrel-purchase','ジムビーム'=>'jim-beam-taste');
    return $ids[$name]??'whisky-note';
}
