<?php
if(!defined('ABSPATH'))exit;
function hsh_quality_aliases($input){
    if(!is_array($input)||count($input)>50)return array();$out=array();
    foreach($input as $from=>$to){if(!is_string($from)||!is_string($to))continue;$from=trim(wp_strip_all_tags($from));$to=trim(wp_strip_all_tags($to));if($from!==''&&$to!==''&&strlen($from)<=150&&strlen($to)<=150)$out[$from]=$to;}return $out;
}
function hsh_quality_order($value){return is_string($value)&&in_array($value,array('newest','updated','route'),true)?$value:'newest';}
function hsh_quality_sort(){
    $value=hsh_quality_order(isset($_GET['hsh_order'])?wp_unslash($_GET['hsh_order']):'');$out='<nav class="hsh-sort" aria-label="記事の並び順">';
    foreach(array('newest'=>'新しい記事から','updated'=>'更新が新しい順','route'=>'おすすめの読む順') as $key=>$label){$url=add_query_arg(array('hsh_order'=>$key,'hsh_kind'=>hsh_brushup_choice(isset($_GET['hsh_kind'])?wp_unslash($_GET['hsh_kind']):'')),hsh_category_url(hsh_current_topic()));$out.='<a href="'.esc_url($url).'"'.($key===$value?' aria-current="true"':'').'>'.esc_html($label).'</a>';}
    return $out.'</nav>';
}
add_action('pre_get_posts',function($q){if(is_admin()||!$q->is_main_query()||!$q->is_category())return;$order=hsh_quality_order(isset($_GET['hsh_order'])?wp_unslash($_GET['hsh_order']):'');if($order==='updated'){$q->set('orderby',array('modified'=>'DESC','ID'=>'DESC'));return;}if($order!=='route')return;$ids=array();$slugs=array_unique(array_merge(array_values(hsh_reader_starters()),array_column(hsh_catalog(),'slug')));$allowed=$q->get('post__in');foreach($slugs as $slug){$p=get_page_by_path($slug,OBJECT,'post');if($p&&$p->post_status==='publish'&&(!$allowed||in_array((int)$p->ID,$allowed,true)))$ids[]=(int)$p->ID;}$q->set('post__in',$ids?:array(0));$q->set('orderby','post__in');},45);
add_filter('wp_robots',function($r){if(isset($_GET['hsh_order'])&&hsh_current_topic()){$r['noindex']=true;unset($r['index']);}return $r;},45);
add_action('wp_enqueue_scripts',function(){if(!hsh_reader_scope())return;wp_enqueue_style('hsh-quality',plugin_dir_url(__FILE__).'assets/quality.css',array('hsh-studio'),'1.38.9');wp_enqueue_script('hsh-quality',plugin_dir_url(__FILE__).'assets/quality.js',array('hsh-studio'),'1.38.2',true);},150);
add_action('admin_menu',function(){add_theme_page('検索の表記ゆれ','検索の表記ゆれ','manage_options','hsh-search-aliases','hsh_quality_alias_admin');});
function hsh_quality_alias_admin(){if(!current_user_can('manage_options'))return;$message='';if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){check_admin_referer('hsh_search_aliases');$raw=wp_unslash($_POST['aliases']??'');$map=array();if(is_string($raw)&&strlen($raw)<=16000)foreach(explode("\n",$raw) as $line){$pair=explode('=',trim($line),2);if(count($pair)===2)$map[trim($pair[0])]=trim($pair[1]);}$map=hsh_quality_aliases($map);update_option('hsh_search_aliases',$map,false);$message='検索の表記ゆれを保存しました。';}$map=hsh_quality_aliases(get_option('hsh_search_aliases',array()));$lines=array();foreach($map as $key=>$value)$lines[]=$key.'='.$value;echo '<div class="wrap"><h1>検索の表記ゆれ</h1><p>'.esc_html($message).'</p><p>1行に「入力される言葉=記事で使う言葉」。最大50件。正規表現やHTMLは使いません。既存の標準辞書も有効です。</p><form method="post">';wp_nonce_field('hsh_search_aliases');echo '<label for="hsh-aliases">追加する表記ゆれ</label><p><textarea id="hsh-aliases" name="aliases" rows="14" cols="65" maxlength="16000">'.esc_textarea(implode("\n",$lines)).'</textarea></p><button class="button button-primary">保存する</button></form></div>';}

