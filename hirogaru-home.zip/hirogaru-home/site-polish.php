<?php
if (!defined('ABSPATH')) { exit; }
function hsh_topic_details() {
    return array(
        'cats'=>array('うちの猫は、まんもすです','保護猫まんもすとの日々を、写真と一緒に紹介しています。猫を迎える準備や、キャリー・おもちゃの選び方もまとめています。','cat-carrier-checklist','キャリーは、どこを見て選ぶ？','保護猫まんもすとの日々や、猫を迎える準備、キャリー・おもちゃの選び方を紹介しています。'),
        'whisky'=>array('普段は薄めのハイボールにしています','グレンリベット12年やグレンファークラス12年など、実際に飲んだウイスキーの感想をまとめています。ハイボールの分量や、ラベルの読み方も紹介しています。','highball-measure-and-adjust','ハイボールが薄いと感じたら','実際に飲んだウイスキーの感想や、ハイボールの作り方を紹介しています。'),
        'it-freelance'=>array('正社員が一番だと思っていたけれど','正社員から派遣社員を経て、今は個人事業主。どちらが上という話ではなく、自分に合う働き方を探してきた話です。お金や休み、契約の違いも調べています。','employee-vs-self-employed','正社員と個人事業主、何が違う？','正社員と個人事業主の違いや、自分に合う働き方を考える記事をまとめています。'),
    );
}
function hsh_current_topic() {
    foreach (hsh_topics() as $slug => $topic) { if (is_category($slug)) { return $slug; } }
    return '';
}
add_filter('template_include', function ($template) {
    return hsh_current_topic() ? plugin_dir_path(__FILE__) . 'category-template.php' : $template;
}, 100);
function hsh_profile_markup() {
    return '<aside class="hsh-profile" aria-label="書き手について"><img src="' . esc_url(plugin_dir_url(__FILE__) . 'assets/photos/manmos-front.webp') . '" alt="保護猫のまんもす。管理人提供の写真です。" width="160" height="160" loading="lazy"><div><p class="hsh-kicker">書いている人</p><strong>ひろがる趣味暮らし 管理人</strong><p>まんもすと暮らすウイスキー好きです。以前はMRとして働き、今はフリーランスでデータを扱う仕事をしています。</p><a href="' . esc_url(home_url('/hsh-about/')) . '">もう少し詳しい自己紹介 →</a><br><a href="' . esc_url(home_url('/manmos-cat-life/')) . '">まんもすとの暮らし</a> ／ <a href="' . esc_url(home_url('/it-data-work-flow/')) . '">今の働き方</a><small>写真は、管理人と暮らすまんもすです。</small></div></aside>';
}
function hsh_search_markup($id) {
    $value=function_exists('get_search_query')?get_search_query(false):'';
    if(isset($_GET['s'])&&is_string($_GET['s']))$value=wp_unslash($_GET['s']);
    $topic=function_exists('hsh_search_topic')?hsh_search_topic(isset($_GET['hsh_topic'])?wp_unslash($_GET['hsh_topic']):''):'';
    $options='<option value="">全カテゴリー</option>';
    foreach(hsh_topics() as $key=>$t)$options.='<option value="'.esc_attr($key).'"'.($topic===$key?' selected':'').'>'.esc_html($t[0]).'</option>';
    return '<form class="hsh-search" role="search" method="get" action="'.esc_url(home_url('/')).'"><label for="'.esc_attr($id).'">ブログ内を検索</label><div><input id="'.esc_attr($id).'" name="s" type="search" value="'.esc_attr($value).'" maxlength="100" placeholder="キャリー、ハイボール、CSVなど"><select name="hsh_topic" aria-label="検索するカテゴリー">'.$options.'</select><button type="submit">検索</button></div></form>';
}
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('hsh-reading', plugin_dir_url(__FILE__) . 'assets/reading.css', array(), '1.47.0');
    if (hsh_current_topic() || ((int)get_option('hsh_page_id') && is_page((int)get_option('hsh_page_id')))) {
        foreach (array('cocoon-style','cocoon-keyframes','font-awesome-style','icomoon-style','baguettebox-style','cocoon-child-style','cocoon-child-keyframes','contact-form-7') as $handle) { wp_dequeue_style($handle); }
    }
}, 100);
add_filter('the_content', function ($content) {
    if (!is_singular('post') || !in_the_loop() || !is_main_query()) { return $content; }
    $id = get_the_ID();
    if (!get_post_meta($id, '_hsh_starter_owned', true)) { return $content; }
    $slug = get_post_field('post_name', $id); $details = hsh_topic_details();
    foreach ($details as $topic => $d) {
        if ($d[2] !== $slug) { continue; }
        $url = hsh_category_url($topic);
        $content .= hsh_related_markup($topic,$id) . hsh_article_review_note($slug) . '<section class="hsh-next"><h2>同じカテゴリーの記事</h2><p>' . esc_html($d[4]) . '</p><a href="' . esc_url($url) . '">' . esc_html(hsh_topics()[$topic][0]) . 'の記事一覧 →</a></section>';
    }
    $intro=hsh_intro_post();
    if(!is_wp_error($intro)){$content.='<p class="hsh-next-overview"><a href="'.esc_url(get_permalink($intro)).'">このブログで読めることを見る →</a></p>';}
    return $content . hsh_profile_markup();
}, 20);
add_action('wp_footer', function () {
    if (is_page((int)get_option('hsh_page_id')) || hsh_current_topic() || is_search()) { return; }
    echo '<nav class="hsh-bottom-nav" aria-label="ブログの案内"><a href="' . esc_url(home_url('/')) . '">トップ</a>';
    foreach (hsh_topics() as $slug => $t) { echo '<a href="' . esc_url(hsh_category_url($slug)) . '">' . esc_html($t[0]) . '</a>'; }
    echo '<a href="' . esc_url(home_url('/hsh-about/')) . '">プロフィール</a></nav>';
});
// Aggregate page requests only: no IP address, cookie, user ID or user agent is saved.
add_action('template_redirect', function () {
    if (is_admin() || is_user_logged_in() || is_feed() || is_preview() || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') { return; }
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (preg_match('/bot|crawl|spider|preview|headless|uptime|monitor/i', $ua)) { return; }
    if (!is_singular('post') || !hsh_owned_blog_post(get_post(get_queried_object_id()))) { return; }
    $slug = get_post_field('post_name', get_queried_object_id());
    $day = wp_date('Y_m_d'); $counts = get_option('hsh_request_counts', array());
    $threshold = wp_date('Y_m_d',time()-89*DAY_IN_SECONDS);
    foreach ($counts as $date => $rows) { if ($date < $threshold || $date > $day) { unset($counts[$date]); } }
    if (!isset($counts[$day])) { $counts[$day] = get_option('hsh_requests_'.$day,array()); delete_option('hsh_requests_'.$day); }
    $counts[$day][$slug] = 1 + (int)($counts[$day][$slug] ?? 0);
    update_option('hsh_request_counts', $counts, false);
});
add_action('rest_api_init', function () {
    register_rest_route('hirogaru/v1','/site-audit',array('methods'=>'GET','permission_callback'=>'hsh_edit_permission','callback'=>'hsh_site_audit'));
});
function hsh_site_audit() {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    global $wp_version; $plugins = array();
    foreach (get_plugins() as $file => $p) { $plugins[] = array('name'=>$p['Name'],'version'=>$p['Version'],'active'=>is_plugin_active($file)); }
    $counts = get_option('hsh_request_counts', array()); $threshold=wp_date('Y_m_d',time()-89*DAY_IN_SECONDS);
    foreach($counts as $date=>$rows){if($date<$threshold){unset($counts[$date]);}} krsort($counts);
    return hsh_edit_response(array('wordpress'=>$wp_version,'php'=>PHP_VERSION,'public_indexing'=>(bool)get_option('blog_public'),'sitemap'=>home_url('/wp-sitemap.xml'),'updater'=>array('direct_filesystem'=>get_filesystem_method()==='direct','zip_archive'=>class_exists('ZipArchive'),'file_mods_allowed'=>!(defined('DISALLOW_FILE_MODS')&&DISALLOW_FILE_MODS),'last_update'=>get_option('hsh_last_plugin_update',null)),'plugins'=>$plugins,'backup'=>array('scope'=>'owned content can be exported using status and starter-review; hosting/database/media restore not verified','hosting_backup_verified'=>false),'search_console_connected'=>function_exists('hsh_gsc_connection_status')?hsh_gsc_connection_status()['connected']:false,'measurement'=>array('kind'=>'approximate_uncached_page_requests','limitations'=>'キャッシュ配信・未知のボット・同時更新の影響あり。訪問者数や正確なPVではありません。','daily'=>$counts,'affiliate_links_configured'=>false)));
}
function hsh_verification_value($data) {
    if (!is_array($data) || array_keys($data)!==array('token') || !is_string($data['token']) || !preg_match('/^[A-Za-z0-9_-]{20,200}$/D',$data['token'])) { return new WP_Error('hsh_verification','Googleが発行した確認用トークンだけを指定してください。',array('status'=>400)); }
    return $data['token'];
}
add_action('rest_api_init',function(){register_rest_route('hirogaru/v1','/site-verification',array('methods'=>'POST','permission_callback'=>'hsh_edit_permission','callback'=>function($request){$token=hsh_verification_value($request->get_json_params());if(is_wp_error($token)){return $token;}update_option('hsh_gsc_verification',$token,false);return hsh_edit_response(array('saved'=>true,'verification_completed'=>false));}));});
add_action('wp_head',function(){if(is_front_page()){ $token=get_option('hsh_gsc_verification','');if(is_string($token)&&preg_match('/^[A-Za-z0-9_-]{20,200}$/D',$token)){echo '<meta name="google-site-verification" content="'.esc_attr($token).'">' . "\n";} }});
add_action('admin_menu',function(){add_theme_page('ブログ運用状況','ブログ運用状況','manage_options','hsh-health',function(){
    if(!current_user_can('manage_options')){return;} $audit=hsh_site_audit()->get_data();
    echo '<div class="wrap"><h1>ブログ運用状況</h1><p>検索登録や成約数を、未接続のまま取得済みとは表示しません。</p><h2>検索への公開</h2><p>'.($audit['public_indexing']?'公開設定は有効です。Googleへの登録・掲載は別途確認が必要です。':'検索エンジンへの公開が無効です。設定を確認してください。').'</p><p><a href="'.esc_url($audit['sitemap']).'">サイトマップを見る</a></p><h2>Search Console</h2><p>所有権確認とサイトマップ送信は完了しています（管理者からの報告）。検索データの自動取得はまだ接続していません。</p><h2>バックアップ</h2><p>専用記事には変更前の履歴を最大10件保持します。これはサイト全体のバックアップではありません。ConoHa側のデータベース・メディアを含む復元可否は未確認です。</p><h2>記事への到達件数（概数）</h2><p>ログイン中・既知のボットを除外。キャッシュ配信や同時アクセスの影響があり、正確なPV・訪問者数ではありません。個人識別用CookieやIPはこの集計に保存しません。</p><table class="widefat striped"><thead><tr><th>日付</th><th>猫</th><th>ウイスキー</th><th>IT・フリーランス</th></tr></thead><tbody>';
    foreach($audit['measurement']['daily'] as $day=>$counts){echo '<tr><td>'.esc_html(str_replace('_','-',$day)).'</td>';foreach(array('cat-carrier-checklist','highball-measure-and-adjust','csv-import-seven-checks') as $slug){echo '<td>'.(int)($counts[$slug]??0).'</td>';}echo '</tr>';}
    echo '</tbody></table><p><a href="'.esc_url(admin_url('themes.php?page=hsh-search-review')).'">Search ConsoleのCSVから改善候補を確認する</a></p><h2>収益</h2><p>猫向け19案件を掲載しています。広告クリックの集計と、A8側の成約・確定報酬は別です。成約数や売上をクリックだけから推定しません。</p></div>';
});});

/** Custom templates bypass Cocoon header.php, so supply missing SEO basics once. */
function hsh_document_head() {
    ob_start(); wp_head(); $head = ob_get_clean(); echo $head;
    $slug = hsh_current_topic(); $details = hsh_topic_details();
    $description = $slug ? $details[$slug][4] : '保護猫まんもすとの生活やウイスキーの楽しみ方、未経験で始めたITの仕事について書いている個人ブログです。';
    if (!preg_match('/<meta\b[^>]*name=[\'"]description[\'"]/i', $head)) { echo '<meta name="description" content="'.esc_attr($description).'">' . "\n"; }
    if (!preg_match('/<link\b[^>]*rel=[\'"]canonical[\'"]/i', $head)) {
        $url = $slug ? get_pagenum_link(max(1,(int)get_query_var('paged'))) : home_url('/');if(function_exists('remove_query_arg'))$url=remove_query_arg(array('hsh_kind','hsh_order'),$url);
        echo '<link rel="canonical" href="'.esc_url($url).'">' . "\n";
    }
    if(function_exists('hsh_blog_extra_head')){
        $url=$slug?get_pagenum_link(max(1,(int)get_query_var('paged'))):home_url('/');
        $title=$slug?hsh_topics()[$slug][0].' | ひろがる趣味暮らし':'ひろがる趣味暮らし｜猫・ウイスキー・ITの仕事';
        echo hsh_blog_extra_head($head,$url,$description,$title);
    }
}

// Public publisher identifier supplied by the owner in the AdSense setup screen.
function hsh_adsense_publisher() { return 'ca-pub-1945643191231022'; }
function hsh_adsense_head_markup() {
    return '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . esc_attr(hsh_adsense_publisher()) . '" crossorigin="anonymous"></script>' . "\n";
}
add_action('wp_head', function () {
    if (is_admin() || is_feed() || is_preview() || is_404() || is_search() || is_page('hsh-reading-list')) { return; }
    echo hsh_adsense_head_markup();
}, 20);
function hsh_adsense_ads_txt() {
    return 'google.com, ' . substr(hsh_adsense_publisher(), 3) . ', DIRECT, f08c47fec0942fa0' . "\n";
}
// Serve the root text file before WordPress classifies the virtual path as a 404.
add_action('parse_request', function ($wp) {
    if ($wp->request !== 'ads.txt') { return; }
    status_header(200);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo hsh_adsense_ads_txt();
    exit;
}, 0);
function hsh_adsense_privacy_notice() {
    return '<section class="hsh-adsense-privacy"><h2>Googleの広告サービスについて</h2><p>Googleなどの広告配信事業者は、Cookieを使い、当サイトや他のサイトへのアクセス情報に基づいて広告を表示することがあります。パーソナライズされた広告は、<a href="https://www.google.com/settings/ads">Googleの広告設定</a>で変更できます。</p><p>Googleによる情報の利用については、<a href="https://policies.google.com/technologies/partner-sites?hl=ja">Googleのサービスを使用するサイトやアプリから収集した情報の利用</a>をご確認ください。</p></section>';
}
add_filter('the_content', function ($content) {
    $post = get_post();
    if ($post && in_the_loop() && is_main_query() && rawurldecode($post->post_name) === 'プライバシーポリシー') {
        $content .= hsh_adsense_privacy_notice();
    }
    return $content;
}, 32);

/** Contact Form 7 is needed on contact pages, not on every managed article. */
function hsh_reader_needs_contact_assets($slug,$content){
    return rawurldecode($slug)==='お問い合わせ'||strpos($content,'[contact-form-7')!==false||strpos($content,'wp:contact-form-7/')!==false;
}
add_action('wp_enqueue_scripts',function(){
    if(!hsh_reader_scope())return;
    $p=get_post(get_queried_object_id());
    if($p&&hsh_reader_needs_contact_assets($p->post_name,$p->post_content))return;
    wp_dequeue_style('contact-form-7');wp_dequeue_script('contact-form-7');wp_dequeue_script('swv');
},200);

/** Inert until approval and an actual AdSense slot ID are configured. */
function hsh_adsense_slot_markup($slot){
    if(!is_string($slot)||!preg_match('/^[0-9]{10}$/D',$slot))return '';
    return '<aside class="hsh-display-ad" aria-label="広告"><span class="hsh-ad-label">広告</span><ins class="adsbygoogle" style="display:block" data-ad-client="'.esc_attr(hsh_adsense_publisher()).'" data-ad-slot="'.esc_attr($slot).'" data-ad-format="auto" data-full-width-responsive="true"></ins><script>(window.adsbygoogle=window.adsbygoogle||[]).push({});</script></aside>';
}
function hsh_adsense_prepared_slot(){
    if(!get_option('hsh_adsense_manual_enabled',false))return '';
    return hsh_adsense_slot_markup(get_option('hsh_adsense_article_slot',''));
}
