<?php
/**
 * Plugin Name: ひろがる趣味暮らし トップページ
 * Description: 猫・ウイスキー・ITとフリーランスのトップページ。管理画面から適用・復元できます。
 * Version: 1.37.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) { exit; }
function hsh_topics() {
    return array(
        'cats' => array('猫との暮らし', 'まんもすとの暮らしや、キャリー・おもちゃを選ぶときに気になること。これから猫を迎える方に向けた話もあります。', 'CAT LIFE', '01'),
        'whisky' => array('ウイスキー', 'グレンリベット12年を飲んだ感想や、家で作るハイボールの話。自分に合う飲み方を考えてみます。', 'WHISKY', '02'),
        'it-freelance' => array('ITの仕事と働き方', '未経験で始めたITの仕事や、ChatGPT・Codexを使うときの話。データ抽出や並び替えなど、今している作業の話も書いています。', 'WORK', '03'),
    );
}
add_action('admin_menu', function () {
    add_theme_page('ひろがるトップページ', 'ひろがるトップページ', 'manage_options', 'hsh-home', 'hsh_admin');
});
function hsh_admin() {
    if (!current_user_can('manage_options')) { return; }
    $message = '';
    $hsh_new_token = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hsh_action'])) {
        check_admin_referer('hsh_settings');
        $action = sanitize_key(wp_unslash($_POST['hsh_action']));
        if ($action === 'connect') {
            $hsh_new_token = wp_generate_password(64, false, false);
            update_option('hsh_edit_token_hash', hash('sha256', $hsh_new_token), false);
            $message = '接続キーを発行しました。以前のキーは無効です。キーはこの画面に一度だけ表示されます。';
        } elseif ($action === 'disconnect') {
            delete_option('hsh_edit_token_hash');
            $message = '編集接続を無効にしました。';
        } elseif ($action === 'restore') {
            $old = get_option('hsh_original_front');
            $id = (int) get_option('hsh_page_id');
            if (is_array($old) && (int) get_option('page_on_front') === $id) {
                update_option('show_on_front', $old['show_on_front']);
                update_option('page_on_front', $old['page_on_front']);
                delete_option('hsh_original_front');
                $message = '元のトップページ設定に戻しました。作成したページとカテゴリーは残しています。';
            } else { $message = '復元対象の設定がないか、トップページが別のページに変更されています。'; }
        } elseif ($action === 'apply') {
            $result = hsh_apply();
            $message = is_wp_error($result) ? $result->get_error_message() : 'トップページを適用しました。サイトのキャッシュがある場合は削除してください。';
        }
    }
    echo '<div class="wrap"><h1>ひろがる趣味暮らし トップページ</h1>';
    if ($message) { echo '<div class="notice notice-info"><p>' . esc_html($message) . '</p></div>'; }
    echo '<p>猫・ウイスキー・ITとフリーランスの3カテゴリーと、専用トップページを作成します。既存記事・テーマ・メニューは書き換えません。</p><p>適用前にサイトのバックアップを取得してください。トップページには独立したレイアウトを使い、記事ページは現在のテーマで表示します。</p><form method="post">';
    wp_nonce_field('hsh_settings');
    echo '<button class="button button-primary" name="hsh_action" value="apply">トップページを適用</button> <button class="button" name="hsh_action" value="restore">元のトップページ設定に戻す</button></form>';
    if (get_option('hsh_page_id')) { echo '<p><a href="' . esc_url(get_permalink((int) get_option('hsh_page_id'))) . '" target="_blank" rel="noopener">作成したページを見る</a></p>'; }
    hsh_connection_admin($hsh_new_token);
    echo '<p>停止する場合は、先に「元のトップページ設定に戻す」を実行してからプラグインを無効化してください。</p></div>';
}
function hsh_apply() {
    $ids = array();
    foreach (hsh_topics() as $slug => $topic) {
        $term = get_term_by('slug', $slug, 'category');
        if (!$term) {
            $inserted = wp_insert_term($topic[0], 'category', array('slug' => $slug));
            if (is_wp_error($inserted)) { return $inserted; }
            $ids[$slug] = (int) $inserted['term_id'];
        } else { $ids[$slug] = (int) $term->term_id; }
    }
    $id = (int) get_option('hsh_page_id');
    if ($id && get_post_type($id) !== 'page') { return new WP_Error('hsh_page', '保存されたページが見つかりません。設定の確認が必要です。'); }
    if (!$id) {
        $id = wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'ひろがる趣味暮らし', 'post_name' => 'hirogaru-home', 'post_content' => ''), true);
        if (is_wp_error($id)) { return $id; }
        update_option('hsh_page_id', $id);
    }
    if (get_post_status($id) !== 'publish') { return new WP_Error('hsh_status', '専用ページが公開状態ではありません。ページを確認してください。'); }
    update_option('hsh_categories', $ids);
    if (!get_option('hsh_original_front')) {
        update_option('hsh_original_front', array('show_on_front' => get_option('show_on_front'), 'page_on_front' => get_option('page_on_front')), false);
    }
    update_option('page_on_front', $id);
    update_option('show_on_front', 'page');
    return $id;
}
add_filter('template_include', function ($template) {
    $id = (int) get_option('hsh_page_id');
    return $id && is_page($id) ? plugin_dir_path(__FILE__) . 'home-template.php' : $template;
}, 99);
add_action('wp_enqueue_scripts', function () {
    if (((int) get_option('hsh_page_id') && is_page((int) get_option('hsh_page_id'))) || (function_exists('hsh_current_topic') && hsh_current_topic())) {
        wp_enqueue_style('hsh-home', plugin_dir_url(__FILE__) . 'assets/home.css', array(), '1.37.0');
    }
});
function hsh_category_url($slug) {
    $ids = get_option('hsh_categories', array());
    $url = isset($ids[$slug]) ? get_category_link($ids[$slug]) : '';
    return is_wp_error($url) || !$url ? home_url('/') : $url;
}
function hsh_posts($slug, $limit = 3) {
    $ids = get_option('hsh_categories', array());
    return isset($ids[$slug]) ? get_posts(array('category' => (int) $ids[$slug], 'numberposts' => $limit, 'post_status' => 'publish')) : array();
}
register_deactivation_hook(__FILE__, function () {
    $old = get_option('hsh_original_front');
    if (is_array($old) && (int) get_option('page_on_front') === (int) get_option('hsh_page_id')) {
        update_option('show_on_front', $old['show_on_front']);
        update_option('page_on_front', $old['page_on_front']);
        delete_option('hsh_original_front');
    }
});

require_once plugin_dir_path(__FILE__) . 'editing-bridge.php';

require_once plugin_dir_path(__FILE__) . 'starter-posts.php';

require_once plugin_dir_path(__FILE__) . 'article-refresh.php';

require_once plugin_dir_path(__FILE__) . 'plugin-update.php';

require_once plugin_dir_path(__FILE__) . 'site-polish.php';
require_once plugin_dir_path(__FILE__) . 'blog-brushup.php';

require_once plugin_dir_path(__FILE__) . 'introduction.php';

require_once plugin_dir_path(__FILE__) . 'fixed-page-copy.php';

require_once plugin_dir_path(__FILE__) . 'cat-guide-preview.php';

require_once plugin_dir_path(__FILE__) . 'freelance-site.php';

require_once plugin_dir_path(__FILE__) . 'blog-next.php';

require_once plugin_dir_path(__FILE__) . 'photo-gallery.php';

require_once plugin_dir_path(__FILE__) . 'editorial-planner.php';

require_once plugin_dir_path(__FILE__) . 'growth.php';
require_once plugin_dir_path(__FILE__) . 'growth-operations.php';

require_once plugin_dir_path(__FILE__) . 'reader-experience.php';
require_once plugin_dir_path(__FILE__) . 'reader-operations.php';

require_once plugin_dir_path(__FILE__) . 'reader-brushup.php';
require_once plugin_dir_path(__FILE__) . 'engagement.php';

require_once plugin_dir_path(__FILE__) . 'reader-studio.php';
require_once plugin_dir_path(__FILE__) . 'reader-quality.php';

/** Short, grouped labels keep long article titles out of the site footer. */
function hsh_readable_footer(){
    $groups=array(
      '記事を探す'=>array('/category/cats/'=>'猫との暮らし','/category/whisky/'=>'ウイスキー','/category/it-freelance/'=>'ITの仕事と働き方','/hsh-reading-list/'=>'保存した記事'),
      '写真と体験談'=>array('/hsh-gallery/'=>'まんもすの写真','/hsh-whisky-notes/'=>'飲んだウイスキー','/hsh-hakushu-visit/'=>'白州の蒸溜所見学','/hsh-updates/'=>'最近の更新'),
      'このブログについて'=>array('/hsh-about/'=>'プロフィール','/hsh-editorial/'=>'記事・広告について','/お問い合わせ/'=>'お問い合わせ','/プライバシーポリシー/'=>'プライバシーポリシー'));
    $out='<footer class="hsh-footer hsh-footer-readable"><div class="hsh-footer-brand"><a href="'.esc_url(home_url('/')).'">ひろがる趣味暮らし</a><p>猫との暮らし、ウイスキー、仕事の話。</p></div><nav aria-label="サイト情報">';
    foreach($groups as $title=>$links){$out.='<section><h2>'.esc_html($title).'</h2><ul>';foreach($links as $url=>$label)$out.='<li><a href="'.esc_url(home_url($url)).'">'.esc_html($label).'</a></li>';$out.='</ul></section>';}
    return $out.'</nav><small>© '.esc_html(wp_date('Y')).' ひろがる趣味暮らし</small></footer>';
}
